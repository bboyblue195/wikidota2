/**
 * 
 */
package vn.com.fsoft;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import vn.com.fsoft.model.User;
import vn.com.fsoft.util.HibernateUtil;

/**
 * @author PhongNT9
 *
 */
public class AppMain {

	public static void main(String[] args) {

		// create the User object into the database
		User userObj = new User();
		userObj.setId("U_001");
		userObj.setGroupId("G_001");
		userObj.setFirstName("Phong");
		userObj.setLastName("Nguyen");
		userObj.setPassword("123");
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		// this would save the User object into the database
		session.save(userObj);		
		session.getTransaction().commit();
		
		// close session
		session.close();
		sessionFactory.close();
	}
}

